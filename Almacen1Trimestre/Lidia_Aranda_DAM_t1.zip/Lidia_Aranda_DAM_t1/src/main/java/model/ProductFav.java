package model;

public class ProductFav {
    private int id, idProduct;
}
