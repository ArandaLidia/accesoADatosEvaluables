package controller;

public class ProductFavController {
}
